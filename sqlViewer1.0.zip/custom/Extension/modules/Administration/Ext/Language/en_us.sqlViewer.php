<?php
$mod_strings['LBL_SQLVIEWER_LINK_NAME'] = 'SQL Viewer';
$mod_strings['LBL_SQLVIEWER_LINK_DESCRIPTION'] = 'Formats prepared SQL to be readable';


