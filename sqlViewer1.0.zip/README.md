# sqlViewer
This allows you to recombine a query from your 
SugarCRM log file into a readable query
